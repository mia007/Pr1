package ua.nure.your_last_name.SummaryTask3;

import org.junit.Test;

import ua.nure.your_last_name.SummaryTask3.Demo;

public class DemoTest {

	@Test
	public void test() throws Exception {
		Demo.main(new String[0]);
	}

}
